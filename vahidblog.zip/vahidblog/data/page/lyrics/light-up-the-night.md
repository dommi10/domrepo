---
title: 'Light Up The Night'
date: '2021-01-12'
lastmod: '2021-07-28'
tags: ['France', 'Paris', 'Cemetery', 'Pere Lachaise']
draft: false
summary: 'It is no coincidence that Père Lachaise Cemetery is a paradise for me, a paradise full of people who have played a significant role in my life. I will never forget the first time I came here, I was so excited to meet my favorite musician Frederic Chopin after all these years, but the doors were closed, I was late. But now I’m here to take you to the heaven, a different corner of this cold world.'
images: ['/static/images/canada/toronto.jpg']
authors: ['default']
---

Vahid Takro — Light Up The Night

Ft. Main E Yak & Charles Dickenson & Tristan

Persian Lyrics By: Vahid Takro

Producer: Tristan

–––––––––––––––—
“Chorus”

Singer: Tristan


When the Lights Come On (When the Lights Come On)
Light Up the Night
Light Up the Light
When the Lights come on
–––––––––––––––—
[Verse 1]
Singer: mAIn-E-yAk

Still healing all the bruises that Life had to throw in
Confusion whether to go ahead or give in !!!
give me some time, lemme clear my mind
lemme try to unwind, gotta press rewind
Just being realistic, struggle was the way we lived it
waking up to make a living, stomachs that needed filling…
If Life had a better way, i wanna live another day
but not sure if I’d wish I was born another day!
Sitting alone and your thoughts keep flowing
to realize you ain’t the one you thought you was growing
Lotta these cats under these circumstances,
Lotta these cats drive Mercs n Benz…
Things used to be on a Barter System
Now all we do is leave promises with ’em
But this promise i know ima get it right
When the Lights come on !! Ima Light Up The Night!

–––––––––––––––—
“Chorus”
Singer: Tristan

Light Up The Light
Light Up the Night
When the Lights Come On (When the Lights Come On)
Light Up the Night
Light Up the Light
When the Lights come on
–––––––––––––––—
[Verse 2]
Singer: Vahid Takro

Looking up in the sky every night for a vision
i wasn’t rich either sober
Just a pen, a paper and sour words
wild world and impossible visions
Dirty streets and craving people
They all mean my life
I don’t know why we still alive
It’s been years that I’m obsessed
the photos that I laughed is for years ago
You can tell the quietness deep in my eyes
got blinded who ever looked in my eyes
Life is a gamble, a war kid
Who ever climbed up is a man for war
I still think about flying
I will press the bottom and fly to the sky
–––––––––––––––—
“Chorus”
Singer: Tristan

Light Up The Light
Light Up the Night
When the Lights Come On (When the Lights Come On)
Light Up the Night
Light Up the Light
When the Lights come on
–––––––––––––––—
[Verse 3]
Singer: Charles Dickenson

I’ve distanced away Lord, i am sorry that it hurt you
Bring me close make my life short like commercial
My father getting old now and he looking for those pills
But i have no job with me, trying to feed off my skills
Trying to earn me some bread and i promise gonna break it
Share it with my people and to live my life sacred
Spreading love with it, take the root off that evil
But its difficult for me when you look at some people
Who live their lives busy trying to feed off that evil
The same spirit trying to haunt me, but i stay grounded
Listening to your teaching n i gotta pay homage
Looking for direction and a future in this puzzle
Yes i want a family and kids by the dozen
But the way its looking now my nephew won’t have any cousins
My struggles getting tougher and i am looking for some light
Even though its day time help me light up the night
–––––––––––––––—
“Chorus”
Singer: Tristan

Light Up The Light
Light Up the Night
When the Lights Come On (When the Lights Come On)
Light Up the Night
Light Up the Light
When the Lights come on

…

Light Up The Light

––––––––––––––––––––––––––—
FINGLISH WORDS
For Second Verse By Vahid Takro
––––––––––––––––––––––––––—

[Verse 2]
Singer: Vahid Takro

harshab too asemoonaam donbale hadaf
naboodam hichvaght pooldaro nasakh
faghat ye khodkar, kaghaz, harfaye talkh
donyaye vahishi, ahdafe sakht
khiaboone kasifo adamaye khomar
roozaye tekrari, zendegie ghomar
manie ina shode zendegim
nemidoonam chera hanooz zendeim
too khodamam alan chand sali mishe
aksaye khandeham chand sale pishe
sokouto mishe fahmid az omghe chehram
kar shod harki ke zol zad too cheshmam
zendegi ghomare ye jange bache
harki raft bala ye marde jange
hanooz fekr mikonam man be parvaaz
fioozo mizanam miram roo abra

–––––––––––––––—