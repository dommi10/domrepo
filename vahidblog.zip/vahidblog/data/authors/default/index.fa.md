---
name: Farsi Vahid Takro
avatar: /static/images/avatar.png
occupation: www.vahidtakro.com
company: vahidtakro
email: address@yoursite.com
twitter: https://twitter.com
instagram: https://instagram.com
---

bio