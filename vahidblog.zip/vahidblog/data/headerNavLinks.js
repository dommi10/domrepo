const headerNavLinks = [
  { href: '/blog', title: 'Blog' },
  { href: '/tags', title: 'Tags' },
  { href: '/projects', title: 'Projects' },
  { href: '/destinations', title: 'Destinations' },
  { href: '/biography', title: 'Who am I?' },
]

export default headerNavLinks
